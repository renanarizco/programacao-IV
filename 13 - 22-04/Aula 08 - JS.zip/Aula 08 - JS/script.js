
for(var i = 0; i <= 10; i++) {
    document.writeln("<font color = 'blue'>" + i + "</font><br/>");
}

document.write("</br>");

for(var i = 10; i >= 0; i--){
    document.writeln("<font color = 'crimson'>" + i + "</font><br/>");
}